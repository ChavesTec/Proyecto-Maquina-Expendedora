from machine import ADC, Pin, PWM
import socket
import network
import json
from time import sleep, ticks_ms

# ====================================
# WIFI
# ====================================

SSID     = "Iphone 20 de Daniel"
PASSWORD = "Dansol1702"
PORT     = 1717

# ====================================
# POTENCIOMETRO
# ====================================

pot = ADC(26)

# ====================================
# LEDS
# ====================================

led1 = Pin(15, Pin.OUT)
led2 = Pin(16, Pin.OUT)
led3 = Pin(17, Pin.OUT)

# ====================================
# BOTON
# ====================================

boton = Pin(14, Pin.IN, Pin.PULL_UP)

# ====================================
# SERVOS
# ====================================

servo1 = PWM(Pin(18))
servo2 = PWM(Pin(19))
servo3 = PWM(Pin(20))

servo1.freq(50)
servo2.freq(50)
servo3.freq(50)

# ====================================
# DISPLAY 7 SEGMENTOS
# ====================================

a = Pin(0, Pin.OUT)
b = Pin(1, Pin.OUT)
c = Pin(2, Pin.OUT)
d = Pin(3, Pin.OUT)
e = Pin(4, Pin.OUT)
f = Pin(5, Pin.OUT)
g = Pin(6, Pin.OUT)

segmentos = [a, b, c, d, e, f, g]

numeros = {
    0: [0,0,0,0,0,0,1],
    1: [1,0,0,1,1,1,1],
    2: [0,0,1,0,0,1,0],
    3: [0,0,0,0,1,1,0],
    4: [1,0,0,1,1,0,0],
    5: [0,1,0,0,1,0,0],
    6: [0,1,0,0,0,0,0],
    7: [0,0,0,1,1,1,1],
    8: [0,0,0,0,0,0,0],
    9: [0,0,0,0,1,0,0]
}

def mostrar_numero(numero):
    patron = numeros[numero]
    for i in range(7):
        segmentos[i].value(patron[i])

def mover_servo(servo, angulo):
    duty = int(1000 + (angulo / 180) * 8000)
    servo.duty_u16(duty)

# ====================================
# INICIAR SERVOS
# ====================================

mover_servo(servo1, 0)
mover_servo(servo2, 0)
mover_servo(servo3, 0)
sleep(1)

# ====================================
# STOCK
# ====================================

stock = [9, 9, 9]

# ====================================
# WIFI
# ====================================

def conectar_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(SSID, PASSWORD)
    print("Conectando a WiFi", end="")
    for _ in range(20):
        if wlan.isconnected():
            break
        print(".", end="")
        sleep(0.5)
    if wlan.isconnected():
        ip = wlan.ifconfig()[0]
        print("\nConectado! IP:", ip)
        return ip
    print("\nError de conexion")
    return None

# ====================================
# SERVIDOR TCP
# ====================================

def iniciar_servidor(ip):
    s = socket.socket()
    s.bind((ip, PORT))
    s.listen(1)
    s.setblocking(False)
    print("Servidor listo en {}:{}".format(ip, PORT))
    return s

ip = conectar_wifi()
servidor = iniciar_servidor(ip)

conn_actual = None

# ====================================
# ESTADO SERVO
# ====================================

servo_activo       = False
servo_obj          = None
servo_angulo_dest  = 0
servo_tiempo_inicio = 0
DURACION_SERVO     = 1000

producto_actual = 1

# ====================================
# LOOP PRINCIPAL
# ====================================

while True:

    ahora = ticks_ms()

    # --- Servo sin sleep ---
    if servo_activo:
        if ahora - servo_tiempo_inicio >= DURACION_SERVO:
            if servo_angulo_dest == 90:
                mover_servo(servo_obj, 0)
                servo_angulo_dest = 0
                servo_tiempo_inicio = ahora
            else:
                servo_activo = False
                servo_obj = None

    # --- Potenciometro y LEDs ---
    valor = pot.read_u16()

    led1.off()
    led2.off()
    led3.off()

    if valor < 22000:
        led1.on()
        producto_actual = 1
        mostrar_numero(stock[0])
    elif valor < 44000:
        led2.on()
        producto_actual = 2
        mostrar_numero(stock[1])
    else:
        led3.on()
        producto_actual = 3
        mostrar_numero(stock[2])

    # --- Boton fisico ---
    if boton.value() == 0 and not servo_activo:
        idx = producto_actual - 1
        if stock[idx] > 0:
            stock[idx] -= 1
            servos = [servo1, servo2, servo3]
            servo_obj = servos[idx]
            mover_servo(servo_obj, 90)
            servo_angulo_dest = 90
            servo_tiempo_inicio = ahora
            servo_activo = True
        sleep(0.3)

    # --- Servidor TCP ---
    try:
        if conn_actual is None:
            try:
                conn_actual, addr = servidor.accept()
                conn_actual.setblocking(False)
                print("Cliente conectado:", addr)
            except:
                pass

        if conn_actual is not None:
            try:
                data = conn_actual.recv(1024)
                if data:
                    msg = data.decode().strip()
                    if msg == "STOCK":
                        respuesta = "{},{},{}\n".format(stock[0], stock[1], stock[2])
                        conn_actual.send(respuesta.encode())
            except OSError:
                pass
            except Exception:
                conn_actual.close()
                conn_actual = None

    except Exception:
        pass

    sleep(0.05)